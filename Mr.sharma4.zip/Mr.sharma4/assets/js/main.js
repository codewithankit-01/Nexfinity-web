/**
 * ==========================================================================
 * ANKIT SHARMA - PORTFOLIO INTERACTIVITY & ANIMATION ENGINE
 * Vanilla JavaScript (ES6+) with 60fps animations,
 * Interactive 3D Parallax Tilt & Cyber Canvas Particles
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {

  const whatsappPhoneNumber = '919672244908';
  const whatsappBaseUrl = `https://wa.me/${whatsappPhoneNumber}`;

  // ==========================================
  // 2. CUSTOM GLOWING CURSOR WITH LERP FOLLOWER
  // ==========================================
  const cursor = document.getElementById('customCursor');
  const follower = document.getElementById('cursorFollower');

  let mouseX = -100, mouseY = -100;
  let followerX = -100, followerY = -100;

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    if (cursor) {
      cursor.style.transform = `translate(${mouseX}px, ${mouseY}px)`;
    }
  });

  function renderFollower() {
    followerX += (mouseX - followerX) * 0.18;
    followerY += (mouseY - followerY) * 0.18;
    if (follower) {
      follower.style.transform = `translate(${followerX}px, ${followerY}px)`;
    }
    requestAnimationFrame(renderFollower);
  }
  requestAnimationFrame(renderFollower);

  // Magnetic & Cursor Hover state triggers
  const interactiveElements = document.querySelectorAll('a, button, input, textarea, select, [data-magnetic], .project-card, .skill-category-card');
  interactiveElements.forEach((el) => {
    el.addEventListener('mouseenter', () => {
      document.body.classList.add('cursor-hover');
    });
    el.addEventListener('mouseleave', () => {
      document.body.classList.remove('cursor-hover');
      el.style.transform = '';
    });
    // Magnetic pull effect
    if (el.hasAttribute('data-magnetic')) {
      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const deltaX = (e.clientX - centerX) * 0.28;
        const deltaY = (e.clientY - centerY) * 0.28;
        el.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
      });
    }
  });

  // ==========================================
  // 3. REALISTIC FIRE SPARKS & FLYING EMBERS BACKGROUND (GPU HARDWARE ACCELERATED)
  // ==========================================
  const canvas = document.getElementById('cyberCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    // Pre-render 4 glowing fire spark sprites onto off-screen canvases (0% CPU lag)
    function createSparkSprite(coreColor, midColor, outerColor) {
      const s = document.createElement('canvas');
      s.width = 64;
      s.height = 64;
      const sctx = s.getContext('2d');
      const g = sctx.createRadialGradient(32, 32, 0, 32, 32, 30);
      g.addColorStop(0, coreColor);
      g.addColorStop(0.18, midColor);
      g.addColorStop(0.55, outerColor);
      g.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sctx.fillStyle = g;
      sctx.beginPath();
      sctx.arc(32, 32, 30, 0, Math.PI * 2);
      sctx.fill();
      return s;
    }

    const sprites = [
      // 0: Hot incandescent amber/gold spark
      createSparkSprite('rgba(255, 255, 255, 1)', 'rgba(255, 185, 40, 1)', 'rgba(255, 75, 0, 0.6)'),
      // 1: Vibrant glowing flame orange
      createSparkSprite('rgba(255, 245, 190, 1)', 'rgba(255, 110, 10, 0.95)', 'rgba(224, 11, 20, 0.6)'),
      // 2: Fiery crimson flame ember
      createSparkSprite('rgba(255, 220, 180, 1)', 'rgba(235, 15, 25, 0.9)', 'rgba(160, 0, 10, 0.5)'),
      // 3: Deep dark ruby ember
      createSparkSprite('rgba(255, 180, 140, 1)', 'rgba(204, 8, 16, 0.85)', 'rgba(100, 0, 5, 0.45)')
    ];

    // Particle count: optimal density without lag
    const particleCount = width > 1200 ? 80 : (width > 768 ? 50 : 30);
    const embers = [];

    function spawnEmber(initial = false) {
      const spriteIdx = Math.floor(Math.random() * sprites.length);
      const isBig = Math.random() < 0.20; // 20% larger flying embers
      const baseRadius = Math.random() * 2.25 + 2.0; // Render radius 2px to 4.25px
      const radius = isBig ? baseRadius * 1.5 : baseRadius;

      return {
        x: Math.random() * width,
        // When initial, spread across full screen; when dynamic, spawn right at bottom edge so they emerge from bottom of screen!
        y: initial ? Math.random() * height : height + Math.random() * 8,
        radius: radius,
        sprite: sprites[spriteIdx],
        speedY: -(Math.random() * 1.5 + 0.8), // Strictly upward speed (no horizontal drift)
        maxAlpha: Math.random() * 0.35 + 0.65, // 0.65 to 1.0 high-visibility glowing opacity
        alpha: Math.random() * 0.3 + 0.7, // High initial alpha so sparks emerge glowing from bottom
        flickerFreq: Math.random() * 0.08 + 0.03,
        flickerPhase: Math.random() * Math.PI * 2,
        aspectRatio: Math.random() * 0.35 + 1.2 // Aerodynamic vertical spark streak
      };
    }

    // Populate initial embers across the whole screen
    for (let i = 0; i < particleCount; i++) {
      embers.push(spawnEmber(true));
    }

    let lastTimestamp = performance.now();

    function animateEmbers(timestamp) {
      const dt = Math.min((timestamp - lastTimestamp) / 16.667, 2.0);
      lastTimestamp = timestamp;

      ctx.clearRect(0, 0, width, height);
      ctx.globalCompositeOperation = 'lighter'; // Natural fire luminescence

      for (let i = 0; i < embers.length; i++) {
        const e = embers[i];

        // 1. Strictly upward motion (sidhe uppar - no left/right movement)
        e.y += e.speedY * dt;

        // 2. Visible from bottom edge; smoothly fade out only near the top
        const progressY = e.y / height; // 1 at bottom, 0 at top
        let targetAlpha = e.maxAlpha;
        if (progressY < 0.12) {
          // Near top: fade out gently into the dark void
          targetAlpha *= Math.max(0, progressY / 0.12);
        }

        // 3. Incandescent flickering shimmer
        const flicker = 0.88 + 0.12 * Math.sin(timestamp * e.flickerFreq + e.flickerPhase);
        e.alpha = Math.max(0, Math.min(1, targetAlpha * flicker));

        // 4. Draw pre-rendered sprite using GPU texture blit (0% CPU lag)
        if (e.alpha > 0.02 && e.y >= -30 && e.y <= height + 30) {
          ctx.globalAlpha = e.alpha;
          const w = e.radius * 2;
          const h = e.radius * 2 * e.aspectRatio;
          ctx.drawImage(e.sprite, e.x - w / 2, e.y - h / 2, w, h);
        }

        // 5. Respawn when off screen at top: emerge fresh from the screen bottom
        if (e.y < -30) {
          embers[i] = spawnEmber(false);
        }
      }

      ctx.globalAlpha = 1.0;
      ctx.globalCompositeOperation = 'source-over';
      requestAnimationFrame(animateEmbers);
    }

    requestAnimationFrame(animateEmbers);
  }

  const terminalCode = document.getElementById('terminalCode');
  if (terminalCode && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const codeTextNodes = [];
    const codeWalker = document.createTreeWalker(terminalCode, NodeFilter.SHOW_TEXT);
    let textNode = codeWalker.nextNode();

    while (textNode) {
      codeTextNodes.push({ node: textNode, text: textNode.textContent });
      textNode.textContent = '';
      textNode = codeWalker.nextNode();
    }

    let nodeIndex = 0;
    let characterIndex = 0;

    function typeTerminalCode() {
      if (nodeIndex >= codeTextNodes.length) {
        terminalCode.classList.remove('is-typing');
        terminalCode.classList.add('is-typed');
        setTimeout(() => {
          codeTextNodes.forEach(({ node }) => {
            node.textContent = '';
          });
          nodeIndex = 0;
          characterIndex = 0;
          terminalCode.classList.remove('is-typed');
          terminalCode.classList.add('is-typing');
          typeTerminalCode();
        }, 1400);
        return;
      }

      const current = codeTextNodes[nodeIndex];
      const character = current.text.charAt(characterIndex);
      current.node.textContent += character;
      characterIndex++;

      if (characterIndex >= current.text.length) {
        nodeIndex++;
        characterIndex = 0;
      }

      setTimeout(typeTerminalCode, character === '\n' ? 90 : 32);
    }

    terminalCode.classList.add('is-typing');
    setTimeout(typeTerminalCode, 500);
  }

  // ==========================================
  // 4. ROTATING DYNAMIC TYPEWRITER
  // ==========================================
  const typewriterElement = document.getElementById('typewriter');
  if (typewriterElement) {
    const roles = [
      'Digital Experiences',
      'Custom Web Platforms',
      'Brand-led Websites',
      'E-commerce Solutions',
      'Modern Technology'
    ];

    let roleIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let typingSpeed = 90;

    function type() {
      const currentRole = roles[roleIndex];

      if (isDeleting) {
        typewriterElement.textContent = currentRole.substring(0, charIndex - 1);
        charIndex--;
        typingSpeed = 45;
      } else {
        typewriterElement.textContent = currentRole.substring(0, charIndex + 1);
        charIndex++;
        typingSpeed = 90;
      }

      if (!isDeleting && charIndex === currentRole.length) {
        typingSpeed = 2200; // Pause at complete word
        isDeleting = true;
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
        typingSpeed = 450;
      }

      setTimeout(type, typingSpeed);
    }

    setTimeout(type, 1000);
  }

  // ==========================================
  // 5. INTERACTIVE 3D PARALLAX TILT
  // ==========================================
  const deskTiltCard = document.getElementById('deskTiltCard');
  const heroVisualWrap = document.getElementById('heroVisualWrap');

  if (deskTiltCard && heroVisualWrap) {
    heroVisualWrap.addEventListener('mousemove', (e) => {
      const rect = heroVisualWrap.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = ((y - centerY) / centerY) * -12;
      const rotateY = ((x - centerX) / centerX) * 12;
      
      deskTiltCard.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
    });

    heroVisualWrap.addEventListener('mouseleave', () => {
      deskTiltCard.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
    });
  }

  // General 3D tilt for cards with [data-tilt]
  const tiltCards = document.querySelectorAll('[data-tilt]');
  tiltCards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotX = ((y - centerY) / centerY) * -6;
      const rotY = ((x - centerX) / centerX) * 6;
      card.style.transform = `perspective(800px) rotateX(${rotX}deg) rotateY(${rotY}deg) translateY(-6px)`;
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });

  // ==========================================
  // 6. ANIMATED NUMBER COUNTERS
  // ==========================================
  const statNumbers = document.querySelectorAll('.stat-number');
  let countersAnimated = false;

  function runCounters() {
    statNumbers.forEach(stat => {
      const target = parseInt(stat.getAttribute('data-target'), 10);
      let count = 0;
      const duration = 1800;
      const frameDuration = 1000 / 60;
      const totalFrames = Math.round(duration / frameDuration);
      let frame = 0;

      function counterStep() {
        frame++;
        const progress = frame / totalFrames;
        // Ease out quad
        const currentCount = Math.round(target * (1 - (1 - progress) * (1 - progress)));
        
        stat.textContent = currentCount;

        if (frame < totalFrames) {
          requestAnimationFrame(counterStep);
        } else {
          stat.textContent = target;
        }
      }
      requestAnimationFrame(counterStep);
    });
  }

  // ==========================================
  // 7. SCROLL OBSERVER & REVEAL ANIMATIONS
  // ==========================================
  const revealElements = document.querySelectorAll('[data-reveal]');

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');

        // Check if hero stats came into view
        if (!countersAnimated && entry.target.querySelector('.stat-number')) {
          countersAnimated = true;
          runCounters();
        }

        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px'
  });

  revealElements.forEach(el => revealObserver.observe(el));

  // If hero is initially in viewport, start counters immediately
  const heroSection = document.getElementById('hero');
  if (heroSection) {
    setTimeout(() => {
      if (!countersAnimated) {
        countersAnimated = true;
        runCounters();
      }
    }, 400);
  }

  // ==========================================
  // 8. STICKY NAVBAR & ACTIVE LINK SPY
  // ==========================================
  const navbar = document.getElementById('navbar');
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    const scrollPos = window.scrollY;

    if (scrollPos > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }

    // Scroll Spy
    let currentId = '';
    sections.forEach(section => {
      const top = section.offsetTop - 120;
      const height = section.offsetHeight;
      if (scrollPos >= top && scrollPos < top + height) {
        currentId = section.getAttribute('id');
      }
    });

    if (currentId) {
      navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${currentId}`) {
          link.classList.add('active');
        }
      });
    }
  });

  // ==========================================
  // 9. MOBILE MENU DRAWER TOGGLE
  // ==========================================
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const drawerCloseBtn = document.getElementById('drawerCloseBtn');
  const mobileNavItems = document.querySelectorAll('.mobile-nav-item');

  function openDrawer() {
    mobileDrawer.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    mobileDrawer.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (hamburgerBtn) hamburgerBtn.addEventListener('click', openDrawer);
  if (drawerCloseBtn) drawerCloseBtn.addEventListener('click', closeDrawer);
  mobileNavItems.forEach(item => item.addEventListener('click', closeDrawer));

  // ==========================================
  // 10. ABOUT SECTION TABS SWITCHER
  // ==========================================
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabTarget = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetContent = document.getElementById(`tab-${tabTarget}`);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });

  // ==========================================
  // 11. SKILLS TABS FILTERING
  // ==========================================
  const skillTabBtns = document.querySelectorAll('.skill-tab-btn');
  const skillCards = document.querySelectorAll('.skill-box-card');

  skillTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      skillTabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-skill-filter');

      skillCards.forEach(card => {
        const cat = card.getAttribute('data-cat');
        if (filter === 'all' || cat === filter) {
          card.style.display = 'flex';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0) scale(1)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'translateY(15px) scale(0.95)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 250);
        }
      });
    });
  });

  // ==========================================
  // 12. FEATURED PROJECTS FILTERING
  // ==========================================
  const filterButtons = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      filterButtons.forEach(b => b.classList.remove('active'));
      button.classList.add('active');

      const filterVal = button.getAttribute('data-filter');

      projectCards.forEach(card => {
        const categories = card.getAttribute('data-category').split(' ');
        if (filterVal === 'all' || categories.includes(filterVal)) {
          card.style.display = 'block';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0) scale(1)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'translateY(20px) scale(0.95)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 300);
        }
      });
    });
  });

  // ==========================================
  // 12. VIDEO / SHOWCASE INTRO MODAL
  // ==========================================
  const openIntroBtn = document.getElementById('openIntroBtn');
  const introModal = document.getElementById('introModal');
  const modalCloseBtn = document.getElementById('modalCloseBtn');

  function openModal() {
    if (introModal) {
      introModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal() {
    if (introModal) {
      introModal.classList.remove('open');
      document.body.style.overflow = '';
    }
  }

  if (openIntroBtn) openIntroBtn.addEventListener('click', openModal);
  if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);

  if (introModal) {
    introModal.addEventListener('click', (e) => {
      if (e.target === introModal) {
        closeModal();
      }
    });
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && introModal && introModal.classList.contains('open')) {
      closeModal();
    }
  });

  // ==========================================
  // 13. WHATSAPP CONTACT FORM & DIRECT CONTACT LINKS
  // ==========================================
  const contactForm = document.getElementById('contactForm');
  const formStatusMsg = document.getElementById('formStatusMsg');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('userName').value.trim();
      const email = document.getElementById('userEmail').value.trim();
      const message = document.getElementById('userMessage').value.trim();
      const projectType = document.getElementById('projectType').selectedOptions[0].textContent.trim();

      if (!name || !email || !message) {
        showStatus('Please fulfill all mandatory data parameters.', 'error');
        return;
      }

      // Email format regex
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        showStatus('Invalid transmission coordinates (email address).', 'error');
        return;
      }

      const inquiry = [
        'New project inquiry for Nexfinity',
        `Name: ${name}`,
        `Email: ${email}`,
        `Project: ${projectType}`,
        `Message: ${message}`
      ].join('\n');
      const whatsappUrl = `${whatsappBaseUrl}?text=${encodeURIComponent(inquiry)}`;

      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    });

    function showStatus(text, type) {
      formStatusMsg.textContent = text;
      formStatusMsg.className = `form-status-msg ${type}`;
      setTimeout(() => {
        formStatusMsg.style.display = 'none';
        formStatusMsg.className = 'form-status-msg';
      }, 6000);
    }
  }

  // ==========================================
  // 14. NEON SIGN FLICKER EFFECT
  // ==========================================
  const neonSign = document.getElementById('neonWallSign');
  if (neonSign) {
    setInterval(() => {
      // Occasional random organic flicker
      if (Math.random() < 0.25) {
        neonSign.style.opacity = '0.35';
        setTimeout(() => {
          neonSign.style.opacity = '1';
        }, 60 + Math.random() * 80);
      }
    }, 2800);
  }

});
